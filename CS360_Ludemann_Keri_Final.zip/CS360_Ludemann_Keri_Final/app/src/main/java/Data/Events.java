package Data;

import java.util.Date;

public class Events {

    private int id;
    private String title;
    private String summary;
    private String date;
    private String time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Events(int id, String title, String summary, String date, String time){
        this.id=id;
        this.title=title;
        this.summary=summary;
        this.date=date;
        this.time=time;
    }
}
