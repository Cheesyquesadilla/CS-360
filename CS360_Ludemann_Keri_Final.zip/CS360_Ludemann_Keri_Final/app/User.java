public class User {

    String title, subtitle, eventDate, eventTime;

    public User(String title, String subtitle, String eventDate, String eventTime) {
        this.title = title;
        this.subtitle = subtitle;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
    }
}
