package com.example.cs360_ludemann_keri_final;

public class AuthenticatedUserManager {

    private AuthenticatedUser authenticatedUser;

    private static AuthenticatedUserManager authenticatedUserManager;

    public static AuthenticatedUserManager getInstance(){
        if(authenticatedUserManager == null){
            authenticatedUserManager = new AuthenticatedUserManager();
        }
        return authenticatedUserManager;
    }

    public void setAuthUser(AuthenticatedUser authUser) {
        this.authenticatedUser = authenticatedUser;
    }

    public AuthenticatedUser getAuthenticatedUser() {
        return authenticatedUser;
    }
}
