package com.example.cs360_ludemann_keri_final;

import android.widget.ArrayAdapter;

import Data.Events;

public class GridAdapterActivity extends ArrayAdapter<Events> {

}
