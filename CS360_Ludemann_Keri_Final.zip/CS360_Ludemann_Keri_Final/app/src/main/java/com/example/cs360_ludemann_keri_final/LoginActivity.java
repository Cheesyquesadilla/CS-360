package com.example.cs360_ludemann_keri_final;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cs360_ludemann_keri_final.databinding.ActivityLoginBinding;

import com.example.cs360_ludemann_keri_final.R;

public class LoginActivity extends AppCompatActivity {

    EditText username, password;
    Button login, register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        username.findViewById(R.id.username);
        password.findViewById(R.id.password);
        login.findViewById(R.id.login);
        register.findViewById(R.id.register);

       login.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
              String email = username.getText().toString();
              String password = password.getText().toString();

              AuthenticatedUser authenticatedUser = new AuthenticatedUser("dummyUser");
              AuthenticatedUserManager.getInstance().setAuthUser(authenticatedUser);

              //Start up MainActivity
           }
       });

       register.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {


               //Go to Register Screen
           }
       });
    }

}