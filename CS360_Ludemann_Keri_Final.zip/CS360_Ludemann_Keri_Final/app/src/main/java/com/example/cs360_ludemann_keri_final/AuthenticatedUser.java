package com.example.cs360_ludemann_keri_final;

public class AuthenticatedUser {

    private String email;

    public AuthenticatedUser(String email) {
        this.email = email;
    }

    public String getEmail(String email) {
        return email;
    }
}
