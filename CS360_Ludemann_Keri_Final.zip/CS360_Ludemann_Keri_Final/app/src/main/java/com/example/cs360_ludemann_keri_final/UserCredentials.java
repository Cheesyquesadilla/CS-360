package com.example.cs360_ludemann_keri_final;

public class UserCredentials {

    private String email;
    private String password;

    public UserCredentials(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public AuthenticatedUser authenticatedUser(UserCredentials credentials){
        // check credentials against DB return new AuthenticatedUser if valid otherwise null
    }

    public boolean add(UserCredentials credentials){
        //check if email already exists, return false. If doesn't exist add to table. return true if added successfully
    }
}
