import static android.os.Build.VERSION_CODES.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ListAdapter extends ArrayAdapter <User> {

    public <userArrayList> ListAdapter (Context context.ArrayList<User>userArrayList){
        super(context,R.Layout.activity_list_item,userArrayList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        User user = getItem(position);

        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.Layout.activity_list_item,parent, false);
        }

        TextView title = convertView.findViewById(R.id.)

        return super.getView(position, convertView, parent);
    }
}
