package Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.cs360_ludemann_keri_final.AuthenticatedUser;

import java.util.ArrayList;
import java.util.List;

public class EventsDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "events.db";
    private static EventsDatabase eventsDatabase;

    public EventsDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static EventsDatabase getInstance(Context context) {
        if (eventsDatabase == null) {
            eventsDatabase = new EventsDatabase(context);
        }
        return eventsDatabase;
    }

    private static final class EventsTable {
        private static final String TABLE = "events";
        private static final String COL_ID = "_id";
        private static final String COL_TITLE = "title";
        private static final String COL_SUM = "summary";
        private static final String COL_DATE = "date";
        private static final String COL_TIME = "time";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table " + EventsTable.TABLE + "( " + EventsTable.COL_ID +
                " Integer primary key autoincrement " + EventsTable.COL_TITLE + ", " +
                EventsTable.COL_SUM + ", " + EventsTable.COL_DATE + ", " + EventsTable.COL_TIME + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + EventsTable.TABLE);
        onCreate(db);
    }

    public List<Events> getEvents(AuthenticatedUser authenticatedUser) {
        List<Events> events = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + EventsTable.TABLE + " where title = ?";
        String title = null;
        Cursor cursor = db.rawQuery(sql, new String[]{title});
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                title = cursor.getString(1);
                String summary = cursor.getString(2);
                String date = cursor.getString(3);
                String time = cursor.getString(4);
                Log.d(TAG, "Event = " + id + ", " + title + ", " + summary + ", " + date + ", " + time);
            }
            while (cursor.moveToNext());

        }
        cursor.close();
    }

    public long addEvent(Events events){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventsTable.COL_TITLE, events.getTitle());
        values.put(EventsTable.COL_SUM, events.getSummary());
        values.put(EventsTable.COL_DATE, events.getDate());
        values.put(EventsTable.COL_TIME, events.getTime());
        long newId = db.insert(EventsTable.TABLE, null, values);
        return newId;
    }

    public boolean editTitle(Events events){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventsTable.COL_TITLE, events.getTitle());
        return true;
    }

    public boolean editSummary(Events events){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventsTable.COL_SUM, events.getSummary());
        return true;
    }

    public boolean editDate(Events events){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventsTable.COL_DATE, events.getDate());
        return true;
    }

    public boolean editTime(Events events){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventsTable.COL_TIME, events.getTime());
        return true;
    }

    public boolean deleteEvent(long id){
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(EventsTable.TABLE, EventsTable.COL_ID + " = ?", new String[] {long.toString(id)});
        return true;
    }


}
